<?php
    header("Location: src/index.php");
    exit;
?>
